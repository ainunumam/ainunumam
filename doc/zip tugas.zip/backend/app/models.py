from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey
from sqlalchemy import Index, Integer, String, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


# ============================================================
# ENUM
# ============================================================

class PlantClass(str, Enum):
    CABAI_NORMAL = "Cabai Normal"
    CABAI_ANTRAKNOSA = "Cabai Antraknosa"
    CABAI_LEAF_CURL = "Cabai Leaf Curl"
    TOMAT_NORMAL = "Tomat Normal"
    TOMAT_EARLY_BLIGHT = "Tomat Early Blight"
    TOMAT_LATE_BLIGHT = "Tomat Late Blight"


class ConfidenceStatus(str, Enum):
    HIGH_CONFIDENCE = "HIGH_CONFIDENCE"
    LOW_CONFIDENCE = "LOW_CONFIDENCE"
    POTENTIAL_OOD = "POTENTIAL_OOD"


class WarningCode(str, Enum):
    LOW_CONFIDENCE = "LOW_CONFIDENCE"
    OOD_DETECTED = "OOD_DETECTED"


class ErrorCode(str, Enum):
    INVALID_IMAGE_FORMAT = "INVALID_IMAGE_FORMAT"
    IMAGE_TOO_LARGE = "IMAGE_TOO_LARGE"
    INVALID_IMAGE_DATA = "INVALID_IMAGE_DATA"
    MODEL_TIMEOUT = "MODEL_TIMEOUT"
    INVALID_REQUEST = "INVALID_REQUEST"
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    PREPROCESSING_FAILED = "PREPROCESSING_FAILED"
    MODEL_UNAVAILABLE = "MODEL_UNAVAILABLE"
    MODEL_INFERENCE_FAILED = "MODEL_INFERENCE_FAILED"


# ============================================================
# PYDANTIC API SCHEMAS
# ============================================================

class Prediction(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    class_: PlantClass = Field(..., alias="class")
    confidence: float = Field(..., ge=0.0, le=1.0)
    confidence_percent: float = Field(..., ge=0.0, le=100.0)
    status: ConfidenceStatus
    ood: bool

    @model_validator(mode="after")
    def validate_confidence_percent(self):
        if abs(self.confidence_percent - self.confidence * 100) > 0.01:
            raise ValueError("confidence_percent harus sesuai dengan confidence * 100")
        return self


class Preprocessing(BaseModel):
    available: bool


class Warning(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    code: WarningCode
    message: str = Field(..., min_length=1)


class DetectionData(BaseModel):
    prediction: Prediction
    preprocessing: Preprocessing
    warning: Optional[Warning] = None
    disclaimer: str = Field(..., min_length=1)


class DetectionResponse(BaseModel):
    success: bool
    data: DetectionData


class ErrorDetail(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    code: ErrorCode
    message: str = Field(..., min_length=1)


class ErrorResponse(BaseModel):
    success: bool
    error: ErrorDetail


class EvaluationRunBase(BaseModel):
    evaluation_type: str = Field(..., min_length=1)
    sample_count: int = Field(..., ge=0)
    accuracy: Optional[float] = Field(default=None, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_real_world_sample_count(self):
        if self.evaluation_type == "real_world" and self.sample_count < 60:
            raise ValueError("Evaluasi real_world membutuhkan minimal 60 sample")
        return self


class EvaluationRunResponse(EvaluationRunBase):
    model_config = ConfigDict(from_attributes=True)
    evaluation_id: UUID
    started_at: datetime
    completed_at: Optional[datetime] = None


class RealWorldTestBase(BaseModel):
    evaluation_id: UUID
    sample_number: int = Field(..., ge=1)
    actual_class: PlantClass
    predicted_class: PlantClass
    confidence: float = Field(..., ge=0.0, le=1.0)
    is_correct: bool
    image_reference: Optional[str] = None


class RealWorldTestResponse(RealWorldTestBase):
    model_config = ConfigDict(from_attributes=True)
    sample_id: UUID
    tested_at: datetime


class ClassMetricBase(BaseModel):
    evaluation_id: UUID
    class_name: PlantClass
    precision: float = Field(..., ge=0.0, le=1.0)
    recall: float = Field(..., ge=0.0, le=1.0)
    f1_score: float = Field(..., ge=0.0, le=1.0)
    support: int = Field(..., ge=0)


class ClassMetricResponse(ClassMetricBase):
    model_config = ConfigDict(from_attributes=True)
    metric_id: UUID


# ============================================================
# SQLALCHEMY
# ============================================================

class Base(DeclarativeBase):
    pass


class PredictionLog(Base):
    __tablename__ = "prediction_log"

    prediction_id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )
    predicted_class: Mapped[str] = mapped_column(String(50), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False)
    is_ood: Mapped[bool] = mapped_column(Boolean, nullable=False)
    processing_time_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    model_version: Mapped[str] = mapped_column(String(50), nullable=False)
    image_hash: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)

    __table_args__ = (
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_prediction_confidence"),
        CheckConstraint(
            "predicted_class IN ('Cabai Normal','Cabai Antraknosa','Cabai Leaf Curl',"
            "'Tomat Normal','Tomat Early Blight','Tomat Late Blight')",
            name="ck_prediction_class"
        ),
        CheckConstraint(
            "status IN ('HIGH_CONFIDENCE','LOW_CONFIDENCE','POTENTIAL_OOD')",
            name="ck_prediction_status"
        ),
        CheckConstraint("processing_time_ms >= 0", name="ck_processing_time"),
        Index("ix_prediction_created_at", "created_at"),
        Index("ix_prediction_class", "predicted_class"),
        Index("ix_prediction_image_hash", "image_hash"),
    )


class EvaluationRun(Base):
    __tablename__ = "evaluation_run"

    evaluation_id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    evaluation_type: Mapped[str] = mapped_column(String(30), nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    sample_count: Mapped[int] = mapped_column(Integer, nullable=False)
    accuracy: Mapped[Optional[float]] = mapped_column(Float)

    real_world_tests: Mapped[list["RealWorldTest"]] = relationship(
        back_populates="evaluation", cascade="all, delete-orphan"
    )
    class_metrics: Mapped[list["ClassMetric"]] = relationship(
        back_populates="evaluation", cascade="all, delete-orphan"
    )

    __table_args__ = (
        CheckConstraint("sample_count >= 0", name="ck_evaluation_sample_count"),
        CheckConstraint(
            "accuracy IS NULL OR (accuracy >= 0 AND accuracy <= 1)",
            name="ck_evaluation_accuracy"
        ),
        Index("ix_evaluation_type", "evaluation_type"),
    )


class RealWorldTest(Base):
    __tablename__ = "real_world_test"

    sample_id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    evaluation_id: Mapped[UUID] = mapped_column(
        ForeignKey("evaluation_run.evaluation_id", ondelete="CASCADE"),
        nullable=False
    )
    sample_number: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_class: Mapped[str] = mapped_column(String(50), nullable=False)
    predicted_class: Mapped[str] = mapped_column(String(50), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    is_correct: Mapped[bool] = mapped_column(Boolean, nullable=False)
    image_reference: Mapped[Optional[str]] = mapped_column(String(255))
    tested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    evaluation: Mapped["EvaluationRun"] = relationship(back_populates="real_world_tests")

    __table_args__ = (
        UniqueConstraint("evaluation_id", "sample_number", name="uq_evaluation_sample_number"),
        CheckConstraint("sample_number >= 1", name="ck_sample_number"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="ck_real_world_confidence"),
        Index("ix_real_world_evaluation_id", "evaluation_id"),
    )


class ClassMetric(Base):
    __tablename__ = "class_metric"

    metric_id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    evaluation_id: Mapped[UUID] = mapped_column(
        ForeignKey("evaluation_run.evaluation_id", ondelete="CASCADE"),
        nullable=False
    )
    class_name: Mapped[str] = mapped_column(String(50), nullable=False)
    precision: Mapped[float] = mapped_column(Float, nullable=False)
    recall: Mapped[float] = mapped_column(Float, nullable=False)
    f1_score: Mapped[float] = mapped_column(Float, nullable=False)
    support: Mapped[int] = mapped_column(Integer, nullable=False)

    evaluation: Mapped["EvaluationRun"] = relationship(back_populates="class_metrics")

    __table_args__ = (
        UniqueConstraint("evaluation_id", "class_name", name="uq_evaluation_class"),
        CheckConstraint("precision >= 0 AND precision <= 1", name="ck_metric_precision"),
        CheckConstraint("recall >= 0 AND recall <= 1", name="ck_metric_recall"),
        CheckConstraint("f1_score >= 0 AND f1_score <= 1", name="ck_metric_f1"),
        CheckConstraint("support >= 0", name="ck_metric_support"),
        Index("ix_class_metric_evaluation_id", "evaluation_id"),
    )

# [ASUMSI-04] Format model_version belum memiliki aturan khusus.
# [ASUMSI-05] Retensi image_hash dan image_reference belum ditentukan.
